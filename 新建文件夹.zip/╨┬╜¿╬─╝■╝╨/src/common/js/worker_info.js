
export default class worker_info {
  constructor({uid, name,avatar, hometown, work_years}) {
    this.uid = uid
    this.name = name
    this.avatar = avatar
    this.hometown = hometown
    this.work_years = work_years
  }

 
}

export function createWorkerInfo(item) {
	
  return new worker_info({
    uid: item.uid,
    name: item.name,
    avatar: item.avatar,
    hometown: item.hometown,
    work_years: item.work_years
  })
 
}

