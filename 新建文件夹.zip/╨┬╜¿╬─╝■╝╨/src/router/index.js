import Vue from 'vue'
import Router from 'vue-router'
import workerList from '@/components/worker_list/worker_list'
import projectList from '@/components/project_list/project_list'
import login from '@/components/login/login'
Vue.use(Router)

export default new Router({
routes: [
		{
      path: '/',
      component: workerList
    },
    {
      path: '/worker_list',
      component: workerList
    },
    {
    	path:'/project_list',
    	component:projectList
    },
    {
    	path:'/login',
    	component:login
    }
]
})
