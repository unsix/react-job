<template>
	<transition name="slide">
		<div class="login-wrapper">
			<div class="login">
				<div class="nav">
					<a :class="{ 'active': isA}" @click="toLogin">登录</a>
					<a :class="{ 'active': isB}" @click="toRegister">注册</a>
				</div>
				<div class="signIn">
					<div class="username">
						<input type="text" placeholder="请输入账号" />
					</div>
					<div class="password">
						<input type="password" placeholder="请输入密码" />
					</div>
					<div class="submit">
						<a>登录</a>
					</div>
				</div>
			</div>
		</div>
	</transition>
</template>

<script>
	export default{
		data(){
			return{
				isA:true,
				isB:false
			}
		},
		methods:{
			toLogin(){
				this.isA = true
				this.isB = false
			},
			toRegister(){
				this.isA = false
				this.isB = true
			}
		}
	}
</script>

<style lang="scss">
$color1:#f4f6fc;
$color2:#cfd8f5;
$color3:#87a0eb;
.slide-enter-active, .slide-leave-active{
	transition: all 0.2s
}
.slide-enter, .slide-leave-to{
	transform: translate3d(100%, 0, 0)
}

	.login-wrapper{
		position: fixed;
		top: 0px;
		right: 0px;
		width: 100%;
		height: 100%;
		background: $color1;
		.login{
			float: right;
			width: 30%;
			height: 100%;
			background:$color2 ;
			.signIn{
				width: 60%;
				margin: 200px auto 0;
				input{
					width: 100%;
					height: 34px;
					border: 1px solid $color3;
					outline: none;
					margin-top: 20px;
					-moz-border-radius: 4px;
					-webkit-border-radius: 4px;
					border-radius: 4px; 
					text-indent: 10px;
				}
				.submit{
					width: 100%;
					a{
						margin-top: 20px;
						display: block;
						width: 100%;
						height: 40px;
						color: #fff;
						line-height: 40px;
						background:$color3;
						text-align: center;
						cursor: pointer;
						&:hover{
							background:#9db5fb ;
						}
					}
				}
			}
			.nav{
				width: 100%;
				a{
					display: inline-block;
					cursor: pointer;
					width: 50%;
					float: left;
					padding: 20px 0;
					text-align: center;
					
					&.active{
						background: $color3;
						color: #fff;
					}
				}
			}
		}
	}
</style>