<template>
	<div class="worker_list">
		
		<div class="list">
			<div class="choose">
				<ul>
					<li>头像</li>
					<li>姓名</li>
					<li>联系方式</li>
					<li>工作年限
						<img src="../../assets/down.svg" alt="" @click="showType" ref="icon"/>
					</li>
					<li>工种</li>
					<li>籍贯</li>
				</ul>
			</div>
					<el-table
					    :data="workerInfo"
					    border
					    style="width: 100%">
					    <el-table-column label="头像"  >
					      <template slot-scope="scope">
					        <img :src="scope.row.avatar" width="40" height="40"/>
					      </template>
					    </el-table-column>
					    <el-table-column
					      prop="name"
					      label="姓名"
					      width="100"
					     >
					    </el-table-column>
					    <el-table-column
					      prop="phone"
					      label="联系方式"
					      width="140">
					    </el-table-column>
					    <el-table-column
					      prop="work_years"
					      label="工作年限"
					      width="100">
					    </el-table-column>
					    <el-table-column
					      prop="work_years"
					      label="工种"
					      width="100">
					    </el-table-column>
					    <el-table-column
					      prop="hometown"
					      label="家乡"
					       width="220">
					    </el-table-column>
					</el-table>
		</div>
	</div>
</template>

<script>
import {createWorkerInfo} from '@/common/js/worker_info'
import {prefixStyle} from '@/common/js/dom'
export default {
    data() {
      return {
      	workerInfo:[],
      	  activeIndex: '1',
        activeIndex2: '1'
      }
    },
    created(){
    	this.getData()
    },
    methods:{
    	 handleSelect(key, keyPath) {
	        console.log(key, keyPath);
	     },
	  	showType(){
	  		alert()
	  	},
    	getData(){	
	    let rec=[]
	    let param = new URLSearchParams();
	    param.append("uid","10000163");
	    this.$http.post("/index/Mobile/Find/nearby_worker",param)
	    
	    .then((res)=>{
	    	 for (let x in res.data.data.nworker)  
			  {  
			   if(res.data.data.nworker[x].avatar.indexOf('jpg')!== -1){
			   	res.data.data.nworker[x].avatar = 'http://img-bbsf.6655.la/FnF0MmO7g-WONz-QYU6BsWMTwNR_'
			   }else{
			   	 	res.data.data.nworker[x].avatar = 'http://img-bbsf.6655.la/' + res.data.data.nworker[x].avatar
			   }
			  }
	     	this.workerInfo=res.data.data.nworker
	     	console.log(this.workerInfo)

	    })
    }
    }
  }
</script>

<style lang="scss">
	.worker_list{
		width: 40%;
		margin: 10px auto;
		font-size: 14px;
		.list{
			position:relative;
			.choose{
				position: absolute;
				top: 2px;
				left: 1px;
				z-index: 1;
				ul{
					li{
						img{
							width: 24px;
							vertical-align: middle;
						}					
						float: left;

						margin-left: 0px;
						border-right: 1px solid #e6ebf5;
						display: inline-block;
						height: 42px;
						line-height: 42px;
						color: #666666;
						text-indent: 10px;
						background:#fff; 
						&:nth-child(1){
							width: 100px;
						}
						&:nth-child(2){
							width: 99px;
						}
						&:nth-child(3){
							width: 139px;
						}
						&:nth-child(4){
							width: 99px;
						}
						&:nth-child(5){
							width: 99px;
						}
						&:nth-child(6){
							width: 218px;
						}
					}
				}
			}
			.el-table__body-wrapper{
				overflow: hidden;
			}
		}
	}
</style>