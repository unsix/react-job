<template>
  <div id="app">
    <top></top>
    <router-view></router-view>
  </div>
</template>

<script>
import top from '@/components/top/top'
export default {
  name: 'app',
  components:{
  	top
  }
}
</script>

<style>
@import '/static/reset.css';
@import '/static/common.scss';
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
